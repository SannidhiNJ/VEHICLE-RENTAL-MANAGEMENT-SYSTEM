package vehiclerentalmanagementsystem;

import javax.swing.* ;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class addVehicle extends JFrame implements ActionListener {
    JTextField t2,t4,t7,t8,t10;
    JComboBox t3,t5,t6;
    JButton b1,b2;
    
    addVehicle(){
        
        
        JPanel panel = new JPanel();
        panel.setBounds(5,5,890,490);
        panel.setBackground(Color.LIGHT_GRAY);
        panel.setLayout(null);
        add(panel);
        
        JLabel l1 = new JLabel("ADD VEHICAL");
        l1.setBounds(140,10,300,40);
        l1.setFont(new Font("Tahoma", Font.BOLD,22));
        l1.setForeground(Color.BLACK);
        panel.add(l1);
        
        JLabel l2 = new JLabel("REG NO :");
        l2.setBounds(64,90,152,22);
        l2.setFont(new Font("Tahoma", Font.BOLD, 14));
        l2.setForeground(Color.BLACK);
        panel.add(l2);
        t2 =new JTextField();
        t2.setBounds(200,90,156,20);
        t2.setFont(new Font("Tahoma", Font.PLAIN, 14));
        t2.setForeground(Color.BLACK);
        t2.setBackground(Color.WHITE);
        panel.add(t2);
        
        JLabel l6 = new JLabel("TYPE :");
        l6.setBounds(64,130,152,22);
        l6.setFont(new Font("Tahoma", Font.BOLD, 14));
        l6.setForeground(Color.BLACK);
        panel.add(l6);

        t6 =new JComboBox(new String[]{"CAR","BIKE",});
        t6.setBounds(200,130,156,20);
        t6.setFont(new Font("Tahoma", Font.PLAIN, 14));
        t6.setForeground(Color.BLACK);
        t6.setBackground( Color.WHITE);
        panel.add(t6);
        
        JLabel l8 = new JLabel("NAME :");
        l8.setBounds(64,170,152,22);
        l8.setFont(new Font("Tahoma", Font.BOLD, 14));
        l8.setForeground(Color.BLACK);
        panel.add(l8);
        t7 =new JTextField();
        t7.setBounds(200,170,156,20);
        t7.setFont(new Font("Tahoma", Font.PLAIN, 14));
        t7.setForeground(Color.BLACK);
        t7.setBackground(Color.WHITE);
        panel.add(t7);
        
        JLabel l9 = new JLabel("MODEL :");
        l9.setBounds(64,210,152,22);
        l9.setFont(new Font("Tahoma", Font.BOLD, 14));
        l9.setForeground(Color.BLACK);
        panel.add(l9);
        t8 =new JTextField();
        t8.setBounds(200,210,156,20);
        t8.setFont(new Font("Tahoma", Font.PLAIN, 14));
        t8.setForeground(Color.BLACK);
        t8.setBackground(Color.WHITE);
        panel.add(t8);
        
        JLabel l3 = new JLabel("AVAILABALITY :");
        l3.setBounds(64,250,152,22);
        l3.setFont(new Font("Tahoma", Font.BOLD, 14));
        l3.setForeground(Color.BLACK);
        panel.add(l3);

        t3 =new JComboBox(new String[] {"AVAILABLE", "OCCUPIED"});
        t3.setBounds(200,250,156,20);
        t3.setFont(new Font("Tahoma", Font.PLAIN, 14));
        t3.setForeground(Color.BLACK);
        t3.setBackground(  Color.WHITE);
        panel.add(t3);
        
        JLabel l10 = new JLabel("PRICE :");
        l10.setBounds(64,290,152,22);
        l10.setFont(new Font("Tahoma", Font.BOLD, 14));
        l10.setForeground(Color.BLACK);
        panel.add(l10);
        t10 =new JTextField();
        t10.setBounds(200,290,156,20);
        t10.setFont(new Font("Tahoma", Font.PLAIN, 14));
        t10.setForeground(Color.BLACK);
        t10.setBackground(Color.WHITE);
        panel.add(t10);
        
         b1 = new JButton("ADD");
        b1.setBounds(64,341,111,33);
        b1.setBackground(Color.BLACK);
        b1.setForeground(Color.WHITE);
        b1.addActionListener(this);
        panel.add(b1);

        b2 = new JButton("BACK");
        b2.setBounds(198,341,111,33);
        b2.setBackground(Color.BLACK);
        b2.setForeground(Color.WHITE);
        b2.addActionListener(this);
        panel.add(b2);
        
        
        ImageIcon imageIcon = new ImageIcon(ClassLoader.getSystemResource("ICONS/both2.png"));
        Image image = imageIcon.getImage().getScaledInstance(300,300,Image.SCALE_DEFAULT);
        ImageIcon imageIcon1 = new ImageIcon(image);
        JLabel label = new JLabel(imageIcon1);
        label.setBounds(500,75,300,300);
        panel.add(label);
        
        setUndecorated(true);
        setLocation(465,150);
        setLayout(null);
        setSize(900,500);
        setVisible(true);
        
    }
        
     @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == b1){
            try{
                con c = new con();
                String regno = t2.getText();
                String type = (String) t6.getSelectedItem();
                String name = t7.getText();
                String model = t8.getText();
                String status = (String)  t3.getSelectedItem();
                String price = t10.getText();
                String q = "insert into vehical2 values('"+regno+"', '"+type+"', '"+name+"', '"+model+"', '"+status+"', '"+price+"')";
                c.statement.executeUpdate(q);

                JOptionPane.showMessageDialog(null,"Vehical Added");
                setVisible(false);

            }catch (Exception E){
                E.printStackTrace();
            }
        }else {
            setVisible(false);
        }

    }
        
  
public static void main(String[] args) {
        new addVehicle();
    }
}
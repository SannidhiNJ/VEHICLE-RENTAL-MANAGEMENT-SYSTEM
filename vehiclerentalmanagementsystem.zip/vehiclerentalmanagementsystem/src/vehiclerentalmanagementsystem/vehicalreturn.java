package vehiclerentalmanagementsystem;

import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

public class vehicalreturn extends JFrame {
    vehicalreturn() {

        JPanel panel = new JPanel();
        panel.setBounds(5, 5, 890, 590);
        panel.setBackground(Color.LIGHT_GRAY);
        panel.setLayout(null);
        add(panel);

        JLabel label = new JLabel("VEHICAL RETURN");
        label.setBounds(100, 10, 200, 30);
        label.setFont(new Font("Tahoma", Font.BOLD, 20));
        label.setForeground(Color.BLACK);
        panel.add(label);

        ImageIcon imageIcon = new ImageIcon(ClassLoader.getSystemResource("ICONS/return.jpeg"));
        Image image = imageIcon.getImage().getScaledInstance(250, 200, Image.SCALE_DEFAULT);
        ImageIcon imageIcon1 = new ImageIcon(image);
        JLabel label1 = new JLabel(imageIcon1);
        label1.setBounds(480, 55, 400, 300);
        panel.add(label1);

        JLabel UserId = new JLabel("CTR NAME :");
        UserId.setBounds(30, 55, 150, 30);
        UserId.setFont(new Font("Tahoma", Font.BOLD, 14));
        UserId.setForeground(Color.BLACK);
        panel.add(UserId);

        Choice Customer = new Choice();
        Customer.setBounds(200, 55, 150, 25);
        panel.add(Customer);

        JLabel roomNum = new JLabel("REG-NO :");
        roomNum.setBounds(30, 100, 150, 30);
        roomNum.setFont(new Font("Tahoma", Font.BOLD, 14));
        roomNum.setForeground(Color.BLACK);
        panel.add(roomNum);

        JLabel labelRoomnumber = new JLabel();
        labelRoomnumber.setBounds(200, 100, 150, 30);
        labelRoomnumber.setFont(new Font("Tahoma", Font.PLAIN, 14));
        labelRoomnumber.setForeground(Color.BLACK);
        panel.add(labelRoomnumber);

        JLabel checkintime1 = new JLabel("MAIL ID :");
        checkintime1.setBounds(30, 143, 150, 30);
        checkintime1.setFont(new Font("Tahoma", Font.BOLD, 14));
        checkintime1.setForeground(Color.BLACK);
        panel.add(checkintime1);

        JLabel labelcheckintime1 = new JLabel();
        labelcheckintime1.setBounds(200, 143, 250, 30);
        labelcheckintime1.setFont(new Font("Tahoma", Font.PLAIN, 14));
        labelcheckintime1.setForeground(Color.BLACK);
        panel.add(labelcheckintime1);

        JLabel checkintime = new JLabel("RENT DATE :");
        checkintime.setBounds(30, 190, 150, 30);
        checkintime.setFont(new Font("Tahoma", Font.BOLD, 14));
        checkintime.setForeground(Color.BLACK);
        panel.add(checkintime);

        JLabel labelcheckintime = new JLabel();
        labelcheckintime.setBounds(200, 190, 200, 30);
        labelcheckintime.setFont(new Font("Tahoma", Font.PLAIN, 14));
        labelcheckintime.setForeground(Color.BLACK);
        panel.add(labelcheckintime);

        JLabel checkouttime = new JLabel("RETURN DATE :");
        checkouttime.setBounds(30, 240, 150, 30);
        checkouttime.setFont(new Font("Tahoma", Font.BOLD, 14));
        checkouttime.setForeground(Color.BLACK);
        panel.add(checkouttime);

        Date date1 = new Date();
        JLabel date = new JLabel("" + date1);
        date.setBounds(200, 240, 200, 30);
        date.setForeground(Color.BLACK);
        date.setFont(new Font("Tahoma", Font.PLAIN, 14));
        panel.add(date);

        JLabel label6 = new JLabel("DEPOSITE :");
        label6.setBounds(30, 300, 150, 14);
        label6.setFont(new Font("Tahoma", Font.BOLD, 14));
        label6.setForeground(Color.BLACK);
        panel.add(label6);

        JLabel textField6 = new JLabel();
        textField6.setBounds(200, 300, 140, 25);
        textField6.setFont(new Font("Tahoma", Font.PLAIN, 14));
        textField6.setForeground(Color.BLACK);
        panel.add(textField6);

        JLabel label611 = new JLabel("RENT AMOUNT :");
        label611.setBounds(30, 350, 150, 14);
        label611.setFont(new Font("Tahoma", Font.BOLD, 14));
        label611.setForeground(Color.BLACK);
        panel.add(label611);

        JTextField textField611 = new JTextField();
        textField611.setBounds(200, 350, 140, 25);
        panel.add(textField611);

        JLabel label7 = new JLabel("BALANCE :");
        label7.setBounds(30, 400, 150, 14);
        label7.setFont(new Font("Tahoma", Font.BOLD, 14));
        label7.setForeground(Color.BLACK);
        panel.add(label7);

        JTextField textField7 = new JTextField();
        textField7.setBounds(200, 400, 140, 25);
        panel.add(textField7);

        JLabel label61 = new JLabel("ANY ISSUES :");
        label61.setBounds(30, 450, 150, 14);
        label61.setFont(new Font("Tahoma", Font.BOLD, 14));
        label61.setForeground(Color.BLACK);
        panel.add(label61);

        JTextField textField61 = new JTextField();
        textField61.setBounds(200, 450, 140, 25);
        panel.add(textField61);

        JLabel label71 = new JLabel("TOTAL :");
        label71.setBounds(30, 500, 150, 14);
        label71.setFont(new Font("Tahoma", Font.BOLD, 14));
        label71.setForeground(Color.BLACK);
        panel.add(label71);

        JTextField textField71 = new JTextField();
        textField71.setBounds(200, 500, 140, 25);
        panel.add(textField71);

        JButton calculateDueFine = new JButton("CALCULATE");
        calculateDueFine.setBounds(350, 400, 20, 25);
        calculateDueFine.setForeground(Color.WHITE);
        calculateDueFine.setBackground(Color.BLACK);
        panel.add(calculateDueFine);

        calculateDueFine.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    SimpleDateFormat sdf = new SimpleDateFormat("EEE MMM dd HH:mm:ss zzz yyyy");
                    String rentDateStr = labelcheckintime.getText();
                    Date rentDate = sdf.parse(rentDateStr);

                    Date returnDate = date1;

                    long diffInMillies = Math.abs(returnDate.getTime() - rentDate.getTime());
                    long diff = TimeUnit.DAYS.convert(diffInMillies, TimeUnit.MILLISECONDS);

                    int dueDays = (int) diff;

                    con c = new con();
                    ResultSet rs = c.statement.executeQuery("select price from vehical2 where regNo = '" + labelRoomnumber.getText() + "'");
                    int rentPerDay = 0;
                    if (rs.next()) {
                        rentPerDay = rs.getInt("price");
                    }

                    int rentAmount = dueDays * rentPerDay;
                    textField611.setText(String.valueOf(rentAmount));

                    int advance = Integer.parseInt(textField6.getText());
                    int balance = rentAmount - advance;
                    textField7.setText(String.valueOf(balance));

                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, "Please enter valid dates.");
                }
            }
        });

        JButton calculateTotal = new JButton("GENERATE");
        calculateTotal.setBounds(350, 500, 20, 25);
        calculateTotal.setForeground(Color.WHITE);
        calculateTotal.setBackground(Color.BLACK);
        panel.add(calculateTotal);

        calculateTotal.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int balance = Integer.parseInt(textField7.getText());
                    int issues = Integer.parseInt(textField61.getText());

                    int total = balance + issues;
                    textField71.setText(String.valueOf(total));
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Please enter valid numbers.");
                }
            }
        });

        try {
            con c = new con();
            ResultSet resultSet = c.statement.executeQuery("select * from customer0");
            while (resultSet.next()) {
                Customer.add(resultSet.getString("name"));
            }
        } catch (Exception E) {
            E.printStackTrace();
        }

        JButton checkOut = new JButton("RETURN");
        checkOut.setBounds(20, 545, 120, 30);
        checkOut.setForeground(Color.WHITE);
        checkOut.setBackground(Color.BLACK);
        panel.add(checkOut);
        checkOut.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    con cv = new con();
                    cv.statement.executeUpdate("delete from customer0 where name = '" + Customer.getSelectedItem() + "'");
                    cv.statement.executeUpdate("update vehical2 set status = 'Available' where regNo = '" + labelRoomnumber.getText() + "'");
                    JOptionPane.showMessageDialog(null, "Done");

                    String customerEmail = labelcheckintime1.getText();
                    String returnDateStr = date.getText();
                    String balanceAmount = textField7.getText();
                    sendEmail(customerEmail, returnDateStr, balanceAmount);

                    setVisible(false);

                } catch (Exception E) {
                    E.printStackTrace();
                }
            }
        });

        JButton check = new JButton("CHECK");
        check.setBounds(300, 545, 120, 30);
        check.setForeground(Color.WHITE);
        check.setBackground(Color.BLACK);
        panel.add(check);
        check.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                con c = new con();
                try {
                    ResultSet resultSet = c.statement.executeQuery("select * from customer0 where name = '" + Customer.getSelectedItem() + "'");
                    while (resultSet.next()) {
                        labelRoomnumber.setText(resultSet.getString("regNo"));
                        labelcheckintime1.setText(resultSet.getString("mailid"));
                        labelcheckintime.setText(resultSet.getString("rentDate"));
                        textField6.setText(resultSet.getString("deposite"));
                    }
                } catch (Exception E) {
                    E.printStackTrace();
                }
            }
        });

        JButton back = new JButton("BACK");
        back.setBounds(160, 545, 120, 30);
        back.setForeground(Color.WHITE);
        back.setBackground(Color.BLACK);
        panel.add(back);
        back.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
            }
        });

        setUndecorated(true);
        setLocation(415, 70);
        setLayout(null);
        setSize(900, 600);
        setVisible(true);
    }

    private void sendEmail(String customerEmail, String returnDate, String balanceAmount) {
        String from = "yeshwanths2813@gmail.com"; // change to your email
        String host = "smtp.gmail.com"; // change to your SMTP server

        Properties properties = System.getProperties();
        properties.setProperty("mail.smtp.host", host);
        properties.setProperty("mail.smtp.port", "587");
        properties.setProperty("mail.smtp.auth", "true");
        properties.setProperty("mail.smtp.starttls.enable", "true");

        Session session = Session.getDefaultInstance(properties, new Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication("yeshwanths2813@gmail.com", "euubhpoktclmfwxd"); // change to your email and password
            }
        });

        try {
            MimeMessage message = new MimeMessage(session);
            message.setFrom(new InternetAddress(from));
            message.addRecipient(Message.RecipientType.TO, new InternetAddress(customerEmail));
            message.setSubject("RETURN CONFORMATION");
            message.setText("Thank you for choosing RENT EXPRESS.Hi your vehicle has been returned on " + returnDate + " and you have paid a balance amount of " + balanceAmount + ". Thank you visit again.");

            Transport.send(message);
            System.out.println("Sent message successfully....");
        } catch (MessagingException mex) {
            mex.printStackTrace();
        }
    }

    public static void main(String[] args) {
        new vehicalreturn();
    }
}

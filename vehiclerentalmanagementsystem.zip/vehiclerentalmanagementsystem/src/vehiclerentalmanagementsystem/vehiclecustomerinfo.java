package vehiclerentalmanagementsystem;

import net.proteanit.sql.DbUtils;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;


public class vehiclecustomerinfo extends JFrame{

    vehiclecustomerinfo (){
        JPanel panel = new JPanel();
        panel.setBounds(5,5,890,590);
        panel.setBackground(Color.LIGHT_GRAY);
        panel.setLayout(null);
        add(panel);
        
         JLabel pus = new JLabel("CUSTOMER INFO");
        pus.setBounds(360,5,200,25);
        pus.setForeground(Color.BLACK);
        pus.setFont(new Font("Tahoma", Font.BOLD, 20));
        panel.add(pus);


        JTable table = new JTable();
        table.setBounds(10,55,900,450);
        table.setBackground(Color.LIGHT_GRAY);
        table.setForeground(Color.black);
        panel.add(table);

        try {

            con c = new con();
            String q = "select * from Customer0";
            ResultSet resultSet = c.statement.executeQuery(q);
            table.setModel(DbUtils.resultSetToTableModel(resultSet));

        }catch (Exception e ){
            e.printStackTrace();
        }

        JLabel id = new JLabel("ID");
        id.setBounds(40,40,100,14);
        id.setForeground(Color.black);
        id.setFont( new Font("Tahoma", Font.BOLD,14));
        panel.add(id);

        JLabel number = new JLabel("ID NO");
        number.setBounds(145,40,100,14);
        number.setForeground(Color.black);
        number.setFont( new Font("Tahoma", Font.BOLD,14));
        panel.add(number);

        JLabel name = new JLabel("NAME");
        name.setBounds(265,40,100,14);
        name.setForeground(Color.black);
        name.setFont( new Font("Tahoma", Font.BOLD,14));
        panel.add(name);

        JLabel gender = new JLabel("GENDER");
        gender.setBounds(365,40,100,14);
        gender.setForeground(Color.black);
        gender.setFont( new Font("Tahoma", Font.BOLD,14));
        panel.add(gender);

        JLabel country = new JLabel("REG-NO");
        country.setBounds(485,40,100,14);
        country.setForeground(Color.black);
        country.setFont( new Font("Tahoma", Font.BOLD,14));
        panel.add(country);

        JLabel room = new JLabel("RENT DATE");
        room.setBounds(590,40,100,14);
        room.setForeground(Color.black);
        room.setFont( new Font("Tahoma", Font.BOLD,14));
        panel.add(room);

        JLabel Time = new JLabel("DEPOSIT");
        Time.setBounds(710,40,100,14);
        Time.setForeground(Color.black);
        Time.setFont( new Font("Tahoma", Font.BOLD,14));
        panel.add(Time);

        JLabel Deposit = new JLabel("MAIL ID");
        Deposit.setBounds(820,40,100,14);
        Deposit.setForeground(Color.black);
        Deposit.setFont( new Font("Tahoma", Font.BOLD,14));
        panel.add(Deposit);

        JButton back = new JButton("BACK");
        back.setBounds(390,540,120,30);
        back.setBackground(Color.BLACK);
        back.setForeground(Color.WHITE);
        panel.add(back);
        back.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
            }
        });


        setUndecorated(true);
        setLayout(null);
        setSize(900,600);
        setLocation(420,100);
        setVisible(true);
    }
    public static void main(String[] args) {
        new vehiclecustomerinfo();
    }
    
}

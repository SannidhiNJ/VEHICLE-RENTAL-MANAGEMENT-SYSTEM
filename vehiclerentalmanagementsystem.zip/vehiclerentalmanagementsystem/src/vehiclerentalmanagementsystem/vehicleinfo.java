
package vehiclerentalmanagementsystem;

import net.proteanit.sql.DbUtils;


import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;

public class vehicleinfo extends JFrame  {
  
    JTable table;
    JButton back;

    vehicleinfo(){
        JPanel panel = new JPanel();
        panel.setBounds(5,5,890,590);
        panel.setBackground(Color.LIGHT_GRAY);
        panel.setLayout(null);
        add(panel);
        
        JLabel pus = new JLabel("VEHICAL INFO");
        pus.setBounds(360,5,160,25);
        pus.setForeground(Color.BLACK);
        pus.setFont(new Font("Tahoma", Font.BOLD, 20));
        panel.add(pus);

    

        table = new JTable();
        table.setBounds(10,100,880,400);
        table.setBackground(Color.LIGHT_GRAY);
        table.setForeground(Color.BLACK);
        panel.add(table);

        try{
            con c = new con();
            String RoomInfo = "select * from vehical2";
            ResultSet resultSet = c.statement.executeQuery(RoomInfo);
            table.setModel(DbUtils.resultSetToTableModel(resultSet));
        }catch (Exception e ){
            e.printStackTrace();
        }

        back = new JButton("BACK");
        back.setBackground(Color.BLACK);
        back.setForeground(Color.WHITE);
        back.setBounds(390,550,120,30);
        panel.add(back);
        back.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
            }
        });

        JLabel room = new JLabel("REG-NO");
        room.setBounds(38,55,80,19);
        room.setForeground(Color.BLACK);
        room.setFont(new Font("Tahoma", Font.BOLD, 14));
        panel.add(room);


        JLabel availability = new JLabel("TYPE");
        availability.setBounds(210,55,80,19);
        availability.setForeground(Color.BLACK);
        availability.setFont(new Font("Tahoma", Font.BOLD, 14));
        panel.add(availability);

        JLabel Clean = new JLabel("NAME");
        Clean.setBounds(346,55,150,19);
        Clean.setForeground(Color.BLACK);
        Clean.setFont(new Font("Tahoma", Font.BOLD, 14));
        panel.add(Clean);


        JLabel Price = new JLabel("MODEL");
        Price.setBounds(480,55,80,19);
        Price.setForeground(Color.BLACK);
        Price.setFont(new Font("Tahoma", Font.BOLD, 14));
        panel.add(Price);

        JLabel Bed = new JLabel("AVAILABALITY");
        Bed.setBounds(615,55,150,19);
        Bed.setForeground(Color.BLACK);
        Bed.setFont(new Font("Tahoma", Font.BOLD, 14));
        panel.add(Bed);  
        
        JLabel Bed2 = new JLabel("PRICE");
        Bed2.setBounds(785,55,80,19);
        Bed2.setForeground(Color.BLACK);
        Bed2.setFont(new Font("Tahoma", Font.BOLD, 14));
        panel.add(Bed2);  
        
        setUndecorated(true);
        setLocation(415,100);
        setLayout(null);
        setSize(900,600);
        setVisible(true);
             
              
       } 
    public static void main(String[] args) {
        new vehicleinfo();
    }
}
        
      


package vehiclerentalmanagementsystem;

import javax.swing.*;
import java.awt.*;

public class splach extends JFrame {
    
splach(){
    
    
    /* JPanel panel1 = new JPanel();
        panel1.setLayout(null);
        panel1.setBounds(0,0,270,820);
        panel1.setBackground(Color.WHITE);
        add(panel1);*/
        
        
    JLabel text = new JLabel("RENT EXPRESS");//making hms visible in screen
    text.setBounds(50, 20, 1000, 50);
    text.setForeground(Color.black);
    text.setFont(new Font("Garamond", Font.BOLD, 50));
    add(text);    
        
        ImageIcon imageIcon = new ImageIcon(ClassLoader.getSystemResource("ICONS/splach.3.jpg"));
        Image i1 = imageIcon.getImage().getScaledInstance(1720,830, Image.SCALE_DEFAULT);
        ImageIcon imageIcon1 = new ImageIcon(i1);
        JLabel label = new JLabel(imageIcon1);
        label.setBounds(0,0,1720,830);
        add(label);
        
        
       /* ImageIcon i111 = new ImageIcon(ClassLoader.getSystemResource("ICONS/loading.gif"));
        Image i22 = i111.getImage().getScaledInstance(200,180, Image.SCALE_DEFAULT);
        ImageIcon imageIcon111 = new ImageIcon(i22);
        JLabel label11 = new JLabel(imageIcon111);
        label11.setBounds(0,0,300,750);
        panel1.add(label11);*/
        
        
        setLayout(null);
        setLocation(0,0);
        setSize(1720,830);
        setVisible(true);

        try {
            Thread.sleep(4000);
            new Login();
            setVisible(false);
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    public static void main(String[] args) {
        new splach();
    }
}
    


